from django.contrib import admin
from .models import Funcionario
# Register your models here.

admin.site.register(Funcionario)