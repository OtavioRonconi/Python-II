from classe import Produto
notebook = Produto('Notebook Dell i7', 5800.90)
input('Pressione qualquer tecla para ver a oferta: ')
notebook.verProduto()
print()

