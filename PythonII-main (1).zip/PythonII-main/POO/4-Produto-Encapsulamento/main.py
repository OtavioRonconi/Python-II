from classe import Produto
notebook = Produto('Notebook Dell i7', 3800, 5800)
print("Mudar preço para 1000")
notebook.precoVenda=100
print("Mudar preço para 5100")
notebook.precoVenda=5100
print('----')



